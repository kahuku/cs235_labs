#include <iostream>
#include <fstream>
#include <set>
#include <vector>
#include <string>
#include <sstream>
#include <map>
#include <list>
using namespace std;

void ReadStrings(string filename, vector<string>& words, set<string>& unique);
void WriteStringsToFile(string filename, const set<string>& words);
void WriteStringsToFile(string filename, const vector<string>& words);
void MapStrings(string filename, map<list<string>, vector<string>>& wordmap, const vector<string> words);
void PrintStuff(map<list<string>, vector<string>>& wordmap);

const int WORDS_TO_PRINT = 100;
const int M = 3;

int main(int argc, char* argv[]) {
	vector<string> words;
	set<string> unique;
	map<list<string>, vector<string>> wordmap;

	ReadStrings(argv[1], words, unique);

	string setFilename = string(argv[1]) + "_set.txt";
	WriteStringsToFile(setFilename, unique);
	string vectorFilename = string(argv[1]) + "_vector.txt";
	WriteStringsToFile(vectorFilename, words);
	
	string mapFilename = string(argv[1]) + "_map.txt";
	MapStrings(mapFilename, wordmap, words);

	PrintStuff(wordmap);

	return 0;
}


void ReadStrings(string filename, vector<string>& words, set<string>& unique){
	string nextLine;
	ifstream in(filename); //stream is connected to the file we passed
	while (getline(in, nextLine)){ //reads a line from the file
		istringstream iss(nextLine); //creates a string stream of the line
		string word;
		while (iss >> word){ //gets each word out of the line
			string nopunct = "";
			for (auto &c : word){ //for each character in word
				if (isalpha(c)){ //if alphabetical. can also use isalnum for alphanumberic
					nopunct += c; //add the character to the string for the word if it isn't a character
				}
			}
			words.push_back(nopunct); //add the word without punctuation to the set and vector
			unique.insert(nopunct);
		}
	}
}

void WriteStringsToFile(string filename, const set<string>& words){
	ofstream ostream;
	ostream.open(filename); //output stream connected to the file passed in
	if (ostream.is_open()){
		for (set<string>::iterator it = words.begin(); it != words.end(); ++it){ //for each item in set
			ostream << *it << endl; //put the word on a new line
		}
		ostream.close();
	}
}

void WriteStringsToFile(string filename, const vector<string>& words){
	ofstream ostream;
	ostream.open(filename); //output file stream is connected to the file passed in
	if (ostream.is_open()){
		for (unsigned int i = 0; i < words.size(); i++){ //for each item in vector
			ostream << words.at(i) << endl; //add the word on a new line
		}
		ostream.close();
	}
}

void MapStrings(string filename, map<list<string>, vector<string>>& wordmap, const vector<string> words){
	//create map
	list<string> first;
	for(int i = 0; i < M; i++){ //for as many words as we want grouped
		first.push_back(""); //sets aside the space for the words
	}

	for (unsigned int i = 0; i < words.size() - 1; i++){ //for each set of 2 entries in vector
		string next = words.at(i);
		wordmap[first].push_back(next); //add first as the key and next as the value
		first.push_back(next); //next is added to the list of strings in first
		first.pop_front(); //the previous beginning of first is removed so we stay with 2 entries in it
	}

	//write map to file
	ofstream ostream;
	ostream.open(filename);
	if (ostream.is_open()){
		for (map<list<string>, vector<string>>::iterator it = wordmap.begin(); it != wordmap.end(); ++it){ //for each word in the vector
			ostream << it->first.front() << ", ";
			for (int i = 0; i < wordmap[it->first].size(); ++i){ //for each entry in the list group. (should be M)
				ostream << wordmap[it->first].at(i) << " "; //add each word in the vector that follows each start word
			}
			ostream << endl;
		}
	}
}

void PrintStuff(map<list<string>, vector<string>>& wordmap){
	/*
	string start = "";
	for (int i = 0; i < 100; i++){
			cout << wordmap[start] << " ";
			start = wordmap[start];
	}
	cout << endl; */

	srand(time(NULL)); // this line initializes the random number generated
                   // so you dont get the same thing every time
	list<string> start;
	for (int i =0; i < M; i++){
		start.push_back("");
	}


	for (int i = 0; i < WORDS_TO_PRINT; i++) {
		if (wordmap[start].size() != 0){
			int ind = rand() % wordmap[start].size(); //selects random word from the starting options
					cout << wordmap[start][ind] << " ";
					start.push_back(wordmap[start][ind]); //start now has the option to become a word from the list of words that follows the previous value of start
					start.pop_front(); //previous value of start removed
			}
	}
	cout << endl;
}