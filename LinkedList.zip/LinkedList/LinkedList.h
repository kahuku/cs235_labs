#pragma once
#include "LinkedListInterface.h"
#include <iostream>
#include <sstream>

using namespace std;


template <class T>
class LinkedList : public LinkedListInterface<T> {
public:
	LinkedList(){
		head = NULL;
		listSize = 0;
	}
	~LinkedList(){
		while(head != NULL){
			Node* current = head;
			head = head->next;
			delete current;
		}
	}

	void insertHead(T value) {
		if (!found(value)){
			Node* prevHead = head;
			head = new Node(value);
			head->next = prevHead;
			listSize++;
		}
		
	}

	void insertTail(T value){
		if (!found(value)){
			Node* ptr = head;
			if (head == NULL){
				head = new Node (value);
			}
			else{
				while (ptr != NULL){
					if (ptr->next == NULL){
						ptr->next = new Node(value);
						break;
					}
					else{
						ptr = ptr->next;
					}
				}
			}
			listSize++;
		}
	}
	void insertAfter(T value, T insertionNode){
		if (!found(value) && found(insertionNode)){
			for (Node* ptr = head; ptr != NULL; ptr = ptr->next){
				if (ptr->data == insertionNode){
					Node* current = ptr;
					Node* newNode = new Node(value, current->next);
					ptr->next = newNode;
					break;
				}
			}
			listSize++;
		}
	}
	void remove(T value){
		if (found(value)){
			if (value == head->data){
				Node* current = head;
				head = head->next;
				delete current;
			}
			else{
				for (Node* ptr = head; ptr->next != NULL; ptr = ptr->next){
					if (ptr->next->data == value || ptr->next == NULL){
						Node* current = ptr;
						Node* toRemove = ptr->next;
						cout << "toRemove: " << toRemove << endl;
						cout << "toRemove->next " << toRemove->next << endl;
						if (toRemove->next != 0){
							cout << "toRemove's next is not 0" << endl;
							current->next = toRemove->next;
						}
						else{
							cout << "In else, toRemove's next is 0" << endl;
							current->next = NULL;
							cout << "In else, current->next = NULL" << endl;
						}
						cout <<"Before delete" << endl;
						delete toRemove;
						cout << "After delete" << endl;
						cout << toString() << endl;
						break;
					}
				}
			}
			listSize--;
		}
		//cout << "Leaving remove" << endl;
	}
	void clear(){
		Node* ptr = head;
		while (ptr != NULL){
			Node* current = ptr;
			ptr = ptr->next;
			delete current;
		}
		listSize = 0;
		head = NULL;
	}
	T at(int index){
		//cout << "In at with index of " << index << endl;
		//cout << toString() << endl;
		if(index >= listSize || index < 0) {
			throw out_of_range("Out of range error thrown\n");
		}
		else{
			Node* ptr = head;
			for (int i = 0; i <= index; i++){
				if (i == index){
					//cout << "Leaving at" << endl << endl;
					return ptr->data;
				}
				else{
					ptr = ptr->next;
				}
			}
		}
	}
	int size(){
		return listSize;
	}
	string toString(){
		//cout << "in toString()" << endl;
		stringstream ss;
		for (Node* ptr = head; ptr != NULL; ptr = ptr->next){
			ss << ptr->data;
			if (ptr->next != NULL){
				ss << " ";
			}
		}
		//cout << "leaving toString()" << endl;
		return ss.str();
	}
	bool found(T value){
		for (Node* ptr = head; ptr != NULL; ptr = ptr->next){
			if (ptr->data == value){
				return true;
			}
		}
		return false;
	}

private:
	struct Node {
		Node* next;
		T data;
		Node(const T& data_item, Node* next_ptr = NULL){
			data = data_item; next = next_ptr;
		}
	};

	Node* head;
	int listSize;
};