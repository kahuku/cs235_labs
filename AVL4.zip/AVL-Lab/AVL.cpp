#include "AVL.h"

NodeInterface* AVL::getRootNode() const
	{
	    return root;
	}

bool AVL::add(int data){
	if (addHelper(data,root) == true){
		//cout << "added " << data << endl << endl;
		return true;
	}
	else {
		//cout << "failed to add " << data << endl << endl;
		return false;
	}
}

bool AVL::addHelper(int dataToAdd, Node*& local_root){
	//cout << "In addHelper " << dataToAdd << endl;
	if (local_root == NULL){ //data not in tree, add it
		local_root = new Node(dataToAdd);
		return true;
	} 
	else{
		if (dataToAdd < local_root->data){ //look left
			bool isAdded = addHelper(dataToAdd, local_root->leftChild);
			if (isAdded){
				rebalance(local_root);
			}
			return isAdded;
		}
		else if (dataToAdd > local_root->data){ //look right
			bool isAdded = addHelper(dataToAdd, local_root->rightChild);
			if (isAdded){
				rebalance(local_root);
			}
			return isAdded;
		}
		else { //data is already in tree
			return false;
		}
	}
}

bool AVL::remove(int data){
	if (removeHelper(data,root)){
		//cout << "removed " << data << endl << endl;
		return true;
	}
	else{
		//cout << "failed to remove " << data << endl << endl;
		return false;
	}
}

bool AVL::removeHelper(int dataToRem, Node*& local_root){
	cout << "In removeHelper " << dataToRem << endl;
	if (local_root == NULL){ 
		return false;
	}
	else if (dataToRem < local_root->data){
		bool isRemoved = removeHelper(dataToRem, local_root->leftChild);
		if (isRemoved){
			rebalance(local_root);
		}
		return isRemoved;
	}
	else if (dataToRem > local_root->data){
		bool isRemoved = removeHelper(dataToRem, local_root->rightChild);
		if (isRemoved){
			rebalance(local_root);
		}
		return isRemoved;
	}
	else{
		if (local_root->leftChild != NULL && local_root->rightChild != NULL){
			Node* newPtr = findRightmost(local_root); 
			local_root->data = newPtr->data;
			bool isRemoved = removeHelper(newPtr->data, local_root->leftChild);
			if (isRemoved){
				rebalance(local_root);
			}
			return isRemoved;
		}
		else if (local_root->leftChild != NULL && local_root->rightChild == NULL){
			Node* left = local_root->leftChild;
			//cout << "Removing local_root directly - leftChild" << endl;
			delete local_root;
			local_root = left;
			return true;
		}
		else if (local_root->rightChild != NULL){
			Node* right = local_root->rightChild;
			//cout << "Removing local_root directly - rightChild" << endl;
			delete local_root;
			local_root = right;
			return true;
		}
		else{
			delete local_root;
			local_root = NULL;
			return true;
		}
	}
}

Node* AVL::findRightmost(Node* old_root){
	Node* rightmost = old_root->leftChild;
	while (rightmost != NULL){
		if (rightmost->rightChild != NULL){
			rightmost = rightmost->rightChild;
		}
		else{
			break;
		}
	}
	return rightmost;
}


void AVL::clear(){
	while (root != NULL){
		remove(root->getData());
	}
}

void AVL::rebalance(Node*& local_root){
	//call printbst
	cout << "In rebalance, LR = " << local_root->data << endl;
	Node* rChild = local_root->rightChild;
	Node* lChild = local_root->leftChild;
	//cout << "LC: " << lChild << " RC: " << rChild << endl;
	int balance = findBalance(lChild, rChild);
	cout << "Balance: " << balance << endl;
	if (balance < -1 || balance > 1) {
		//cout << "Need to rebalance node " << local_root->data << endl;
	}

	//Cases
	//balance 2 = right heavy
	if (balance == 2){
		if (findBalance(rChild->leftChild, rChild->rightChild) >= 1){
			//right right tree
			cout << "RightRight" << endl;
			if (local_root == root){
				//cout << "LR is root" << endl;
				Node* newRoot = local_root->rightChild;
				Node* nRLeft = newRoot->leftChild;
				newRoot->leftChild = local_root;
				local_root->rightChild = nRLeft;
				root = newRoot;
			}
			else{
				Node* a = local_root;
				Node* b = a->rightChild;
				Node* c = b->rightChild;
				Node* p = findParent(local_root, root);
				Node* tmp = b->leftChild;

				if (p->leftChild == local_root){
					p->leftChild = b;
					b->leftChild = a;
					a->rightChild = tmp;
				}
				else if (p->rightChild == local_root){
					p->rightChild = b;
					b->leftChild = a;
					a->rightChild = tmp;
				}
			}
		}
		else if (findBalance(rChild->leftChild, rChild->rightChild) < 1){
			//right left tree
			cout << "RIGHTLEFT" << endl;
			//cout << "rChild balance " << findBalance(rChild->leftChild, rChild->rightChild) << endl;
			if (local_root == root){
				//cout << "LR is root" << endl;
				Node* a = local_root;
				Node* b = a->rightChild;
				Node* c = b->leftChild;

				root = b;
				b->leftChild = a;
				a->rightChild = c;
				rebalance(local_root);
			}
			else{
				Node* a = local_root;
				Node* b = a->rightChild;
				Node* c = b->leftChild;
				Node* cRChild = c->rightChild;
				
				a->rightChild = c;
				c->rightChild = b;
				b->leftChild = cRChild;
				

				//cout << "Finished swap to right right" << endl;
				Node* x = local_root;
				Node* y = x->rightChild;
				Node* z = y->rightChild;
				Node* p = findParent(local_root, root);
				Node* tmp = y->leftChild;

				if (p->leftChild == local_root){
					p->leftChild = y;
					y->leftChild = x;
					x->rightChild = tmp;
				}
				else if (p->rightChild == local_root){
					p->rightChild = y;
					y->leftChild = x;
					x->rightChild = tmp;
				}
				if (local_root->data == -44 && findParent(local_root, root)->data == -34){
					cout << "tripped" << endl;
				}
			}
		}
	}
	
	//balance 2 = left heavy
	else if (balance == -2){
		if (findBalance(lChild->leftChild, lChild->rightChild) >= 1){
			// left right tree
			cout << "LEFTRIGHT" << endl;
			Node* a = local_root;
			Node* b = a->leftChild;
			Node* c = b->rightChild;
			Node* cLChild = c->leftChild;
			
			a->leftChild = c;
			c->leftChild = b;
			b->rightChild = cLChild;

			Node* x = local_root;
			Node* y = x->leftChild;
			Node* z = y->leftChild;
			Node* p = findParent(local_root, root);
			cout << "p " << p->data << endl;

			if (p->rightChild != local_root){
				p->leftChild = y;
				Node* tmp = y->rightChild;
				y->rightChild = x;
				x->leftChild = tmp;
			}
			else if (p->rightChild == local_root){
				Node* newRoot = local_root->leftChild;
				Node* nRRight = newRoot->rightChild;
				Node* lRParent = findParent(local_root, root);
				//cout << "lRParent->data = " << lRParent->data << endl;
				newRoot->rightChild = local_root;
				local_root->leftChild = nRRight;
				lRParent->rightChild = newRoot;
			}
		}
		else if (findBalance(lChild->leftChild, lChild->rightChild) < 1){
			//left left tree
			cout << "LeftLeft" << endl;
			
			if (local_root == root){
				//cout << "LR is root" << endl;
				Node* newRoot = local_root->leftChild;
				Node* nRRight = newRoot->rightChild;
				newRoot->rightChild = local_root;
				local_root->leftChild = nRRight;
				root = newRoot;
			}
			else{
				//cout << "actually rebalancing here" << endl;
				Node* a = local_root;
				Node* b = a->leftChild;
				Node* c = b->leftChild;
				Node* p = findParent(local_root, root);
				//cout << "p " << p->data << endl;

				if (p->rightChild != local_root){
					p->leftChild = b;
					Node* tmp = b->rightChild;
					b->rightChild = a;
					a->leftChild = tmp;
				}
				else if (p->rightChild == local_root){
					Node* newRoot = local_root->leftChild;
					Node* nRRight = newRoot->rightChild;
					Node* lRParent = findParent(local_root, root);
					//cout << "lRParent->data = " << lRParent->data << endl;
					newRoot->rightChild = local_root;
					local_root->leftChild = nRRight;
					lRParent->rightChild = newRoot;
				}
			}
		}
	}
	//cout << "exiting rebalance" << endl;
}

Node* AVL::findParent(const Node* local_root, Node* lRParent){
	if (lRParent->rightChild == local_root || lRParent->leftChild == local_root){
		return lRParent;
	}
	else if (local_root->data < lRParent->data){
		return findParent(local_root,lRParent->leftChild);
	}
	else {
		return findParent(local_root, lRParent->rightChild);
	}
}

int AVL::findBalance(Node* lChild, Node* rChild){
	int lHeight = 0;
	int rHeight = 0;
	if (lChild != NULL){
		//cout << "LC->height: " << lChild->getHeight() << endl;
		lHeight = lChild->getHeight() + 1;
	}
	if (rChild != NULL){
		//cout << "RC->height: " << rChild->getHeight() << endl;
		rHeight = rChild->getHeight() + 1;
	}
	return rHeight - lHeight;
}