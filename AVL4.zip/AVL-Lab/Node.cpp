#include "Node.h"

int Node::getData() const
{
		//cout << "getData"<<endl;
		return(data);
}

NodeInterface * Node::getLeftChild() const
{
			//cout << "getLeft"<<endl;
			return(leftChild);
}

NodeInterface * Node::getRightChild() const
{
			//cout << "getRight"<<endl;
			return(rightChild);
}
void Node::setLeftChild(Node *ptr)
{
			//cout << "setLeft"<<endl;
			leftChild = ptr;
}
void Node::setRightChild(Node *ptr)
{
			//cout << "setRight"<<endl;
			rightChild = ptr;
}

int Node::getHeight(){
	if (leftChild == NULL && rightChild == NULL){
		return 0;
	}
	else if (leftChild != NULL && rightChild != NULL){
		int heightL = leftChild->getHeight();
		int heightR = rightChild->getHeight();
		if (heightL > heightR){
			return heightL + 1;
		}
		else {
			return heightR + 1;
		}
	}
	else if (leftChild != NULL && rightChild == NULL){
		return leftChild->getHeight() + 1;
	}
	else{
		return rightChild->getHeight() + 1;
	}
}