#pragma once
#include "AVLInterface.h"
#include "Node.h"
#include <iostream>

class AVL : public AVLInterface {
public:
	AVL() {root = NULL;}
	~AVL() {clear();}

	NodeInterface * getRootNode() const;

	bool add(int data);

	bool remove(int data);

	void clear();

	void rebalance(Node*& local_root);

	bool addHelper(int dataToAdd, Node*& local_root);
	bool removeHelper(int dataToRem, Node*& local_root);
	Node* findRightmost(Node* old_root);
	Node* findParent(const Node* local_root, Node* lRParent);
	int findBalance(Node* lChild, Node* rChild);
protected:
	Node* root;
};