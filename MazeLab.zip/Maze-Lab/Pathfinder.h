#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include "PathfinderInterface.h"
#include <cmath>
#include <algorithm>
using namespace std;

const int ROW_SIZE = 5;

class Pathfinder: public PathfinderInterface {
public:
	Pathfinder();
	~Pathfinder() {};

	string toString() const;

	bool checkValidity(string file_name);

	void createRandomMaze();

	bool importMaze(string file_name);

	/*
	* solveMaze
	*
	* Attempts to solve the current maze and returns a solution if one is found.
	*
	* A solution to a maze is a list of coordinates for the path from the entrance to the exit
	* (or an empty vector if no solution is found). This list cannot contain duplicates, and
	* any two consecutive coordinates in the list can only differ by 1 for only one
	* coordinate. The entrance cell (0, 0, 0) and the exit cell (4, 4, 4) should be included
	* in the solution. Each string in the solution vector must be of the format "(x, y, z)",
	* where x, y, and z are the integer coordinates of a cell.
	*
	* Understand that most mazes will contain multiple solutions
	*
	* Returns:		vector<string>
	*				A solution to the current maze, or an empty vector if none exists
	*/
	vector<string> solveMaze();

protected:
	int maze_grid[ROW_SIZE][ROW_SIZE][ROW_SIZE];
	vector<string> solution;
	bool find_path(int x, int y, int z, int maze[ROW_SIZE][ROW_SIZE][ROW_SIZE]);
};