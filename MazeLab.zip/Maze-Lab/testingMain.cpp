#include <iostream>
#include "Pathfinder.h"

using namespace std;

int main(){
	Pathfinder pthfndr;

	pthfndr.importMaze("Mazes/Invalid1.txt");
	cout << pthfndr.toString() << endl;

	return 0;
}