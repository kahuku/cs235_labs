#include "Pathfinder.h"
using namespace std;

string Pathfinder::toString() const{
	stringstream ss;
	for (int i = 0; i < ROW_SIZE; i++){ //grid (depth)
		for (int j = 0; j < ROW_SIZE; j++){ //row
			for (int k = 0; k < ROW_SIZE; k++){ //column
				if (maze_grid[j][k][i] == 1 || maze_grid[j][k][i] == 0 || maze_grid[j][k][i] == 2 || maze_grid[j][k][i] == 3){
					ss << maze_grid[j][k][i];
				}
				if (k != ROW_SIZE - 1){
					ss << " ";
				}
			}
			ss << '\n';
		}
		if (i != ROW_SIZE - 1){
			ss << '\n';
		}
	}
	return ss.str();
}

bool Pathfinder::importMaze(string file_name){
	//cout << "In importMaze" << endl;

	ifstream file;
	file.open(file_name.c_str());

	if (file.is_open()){
		if (checkValidity(file_name)){
			string line;
			for (int i = 0; i < ROW_SIZE; i++){ // the whole file of grids. 
				for (int j = 0; j < ROW_SIZE; j++){ //a grid
					getline(file, line);
					stringstream ss(line);
					for(int k = 0; k < ROW_SIZE; k++){ // a single line
						int value;
						ss >> value;
						maze_grid[j][k][i] = value;
					}
				}
				getline(file,line); //ignore the empty line between grids
			}
			cout << endl;
			return true;
		}
		
		else{ //
			cout << "invalid maze" << endl << endl;
			return false;
		}
		
	}
	else{
		cout << "error in importmaze" << endl;
		return false;
	}
}

void Pathfinder::createRandomMaze(){
	for (int i = 0; i < ROW_SIZE; i++){
		for (int j = 0; j < ROW_SIZE; j++){
			for (int k = 0; k < ROW_SIZE; k++){
				maze_grid[i][j][k] = rand() % 2;
			}
		}
	}
	maze_grid[0][0][0] = 1;
	maze_grid[ROW_SIZE - 1][ROW_SIZE - 1][ROW_SIZE - 1] = 1;
}

bool Pathfinder::checkValidity(string file_name){
	int numCells = pow(ROW_SIZE,3);
	int count = 0;
	
	//make string board that is not from the toString funciton
	stringstream ss;
	string line;
	ifstream file;
	file.open(file_name);

	stringstream done;
	int lineCount = 0;
	int temp[ROW_SIZE][ROW_SIZE][ROW_SIZE];
	for (int i = 0; i < ROW_SIZE; i++){
		for (int j = 0; j < ROW_SIZE; j++){
			getline(file, line);
			//lineCount++;
			stringstream ss(line);
			for (int k = 0; k < ROW_SIZE; k++){
				char value;
				ss >> value;
				if (isdigit(value)){
					int valueInt = value - 48;
					temp[j][k][i] = valueInt;
					done << value;
				}
			}
		}
		getline(file,line);
	}

	string board = done.str();

	for (int i = 0; i < board.length(); i++){
		if (board.at(i) ==  '1' || board.at(i) =='0'){
			count++;
		}
	}
	
	ifstream fileAgain;
	fileAgain.open(file_name);
	
	if (fileAgain.is_open()){
		//cout << "Counting lines" << endl;
		while (getline(fileAgain,line)){
			lineCount++;
		}
	}
	
	cout << "Checking validity of " << file_name << endl;
	//cout << "Last entry: " << temp[ROW_SIZE - 1][ROW_SIZE - 1][ROW_SIZE - 1] << endl;
	//cout << "LC: " << lineCount << endl;
	//cout << "Count: " << count << endl;

	if (count == numCells && temp[0][0][0] == 1 && temp[ROW_SIZE - 1][ROW_SIZE - 1][ROW_SIZE - 1] == 1 && lineCount == 29) {
		
		return true;
	}
	else {
		return false;
	}
}


Pathfinder::Pathfinder(){
	for (int i = 0; i < ROW_SIZE; i++){
		for (int j = 0; j < ROW_SIZE; j++){
			for (int k = 0; k < ROW_SIZE; k++){
				maze_grid[i][j][k] = 1;
			}
		}
	}
}

vector<string> Pathfinder::solveMaze(){
	solution.clear();
	find_path(0,0,0, maze_grid);
	
	/*
	for (auto s:solution){
		cout << s << endl;
	}*/

	//reset maze
	
	for (int i = 0; i < ROW_SIZE; i++){
		for (int j = 0; j < ROW_SIZE; j++){
			for (int k = 0; k < ROW_SIZE; k++){
				if (maze_grid[i][j][k] == 2 || maze_grid[i][j][k] == 3){
					maze_grid[i][j][k] = 1;
				}
			}
		}
	}
	reverse(solution.begin(),solution.end());
	return solution;
}

bool Pathfinder::find_path(int x, int y, int z, int maze[ROW_SIZE][ROW_SIZE][ROW_SIZE]){
	if (x < 0 || y < 0 || z < 0 || x >= ROW_SIZE || y >= ROW_SIZE || z >= ROW_SIZE){
		//out of bounds
		return false;
	}
	else if (x == ROW_SIZE - 1 && y == ROW_SIZE - 1 && z == ROW_SIZE - 1){
		cout << "Found 444" << endl;
		//is maze end
		maze[y][x][z] = 3;
		solution.push_back("("+to_string(x)+", "+to_string(y)+", "+to_string(z)+")");
		return true;
	}
	else if (maze[y][x][z] != 1){
		return false; //already been or invalid square
	}
	else {
		//recursive part
		maze[y][x][z] = 3;
		if (find_path(x - 1, y, z, maze) || find_path(x + 1, y, z, maze) || find_path(x, y - 1, z, maze) || find_path(x, y + 1, z, maze) || find_path(x, y, z - 1, maze) || find_path(x, y, z + 1, maze)){
			solution.push_back("("+to_string(x)+", "+to_string(y)+", "+to_string(z)+")");
			return true;
		}
		else{
			maze[y][x][z] = 2;
			return false;
		}
	}
}