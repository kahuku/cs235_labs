#pragma once
#include "QSInterface.h"


using namespace std;

class QS : public QSInterface{
public:
	QS();
	~QS();

	/*
	* sortAll()
	*
	* Sorts elements of the array.  After this function is called, every
	* element in the array is less than or equal its successor.
	*
	* Does nothing if the array is empty.
	*/
	void sortAll();

	void quicksort(int first, int last);

	int medianOfThree(int left, int right);
	int partition(int left, int right, int pivotIndex);
	string getArray() const;
	int getSize() const;
	bool addToArray(int value);
	bool createArray(int capacity);
	void clear();
	void bubbleSort(int& first, int& last, int& middle);
	int switchVals(int& a, int& b);
	bool sorted(int first, int last);
private:
	int* a;
	bool allocated = false;
	int size = 0;
	int indexCounter = 0;
	int runs = 0;
	int runs2 = 0;
	//static int* sizePtr = &size;
};