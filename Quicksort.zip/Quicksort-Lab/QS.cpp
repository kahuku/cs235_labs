#include "QS.h"
#include <sstream>

bool QS::createArray(int capacity){
	//cout << endl << "In create array" << endl;
	//cout << "a = " << a << endl;
	
	if (allocated == true){
		//cout << "a != nullptr" << endl;
		/*
		delete[] a;
		indexCounter = 0;
		size = 0;
		a = 0;
		allocated = false;*/
		clear();
		//cout << "a = " << a << endl;
	}
	if (capacity >= 0){
		a = new int[capacity];
		allocated = true;
		//cout << "Allocated memory for a" << endl;
		//cout << "a = " << a << endl;
		//cout << "*a = " << *a << endl;
		size = capacity;
		return true;
	}
	else{
		//cout << "capacity is invalid" << endl;
		return false;
	}
	
}

bool QS::addToArray(int value){
	if (indexCounter < size){
		a[indexCounter] = value;
		indexCounter++;
		return true;
	}
	else{
		return false;
	}
	
}

int QS::getSize() const{
	return indexCounter;
}

string QS::getArray() const{
	//cout << "In get" << endl;
	stringstream ss;
	for (int i = 0; i < indexCounter; i++){
		ss << a[i];
		if (i != indexCounter - 1){
			ss << ",";
		}
	}
	return ss.str();
}

void QS::clear(){
	//cout << "In clear" << endl;
	/*for (int i = 0; i < size; i++){
		a[i] = NULL;
	}*/
	
	indexCounter = 0;
	size = 0;
	//cout << "in clear" << endl;
	//cout << "Clear, a = " << a << endl;
	//cout << "Clear, *a = " << *a << endl;
	/*for (int i = 0; i < size; i ++){
		a[i] = -1;
	}*/
	if (allocated == true){
		allocated = false;
		delete[] a;
	}
	//cout << "Deleted a" << endl;
	a = nullptr;
	//cout << "A reset to null" << endl;
	//cout << "Exiting clear" << endl;
}

QS::QS(){
	cout << "In constructor" << endl;
}

QS::~QS(){
	//cout << "In destructor" << endl;
	cout << "In destructor" << endl;
	clear();
}

void QS::sortAll(){
	//if (runs < 6){
		quicksort(0, indexCounter - 1);
		cout << "sortAll finished" << endl;
		cout << getArray() << endl << endl << endl;
	//}
	//runs++;
	runs2 = 0;
}

void QS::quicksort(int first, int last){
	int median = 0;
	if (last - first > 0){ //there is data to be sorted
		while(!sorted(first, last) /*&& median != -1 */ && runs2 < 20){
			runs2++;
			cout << "Entering median with " << first << " " << last << endl;
			median = medianOfThree(first, last);
			cout << "Median- " << median << endl << endl;
			int pivotIndex = partition(first, last, median);
			cout << "PivotIndex- " << pivotIndex << endl << endl;
			quicksort(first, pivotIndex);
			quicksort(pivotIndex + 1, last);
		}
	}
}

bool QS::sorted(int first, int last){
	bool sorted = true;
	for (int i = first; i < last; i++){
		if (a[i] > a[i + 1]){
			sorted = false;
		}
	}
	return sorted;
}


int QS::medianOfThree(int left, int right){
	if (left < 0 || right >= indexCounter|| right > size || left >= right){
		cout << "OOB" << endl;
		return -1;
	}
	else{
		int middle = (left + right) / 2;
		bubbleSort(left,right,middle);
		return middle;
	}
	
	if (left >= right){
		cout << "L > R" << endl;
		return -1;
	}
	/*
	else{
		cout << "MedianOfThree: " << middle << endl;
		return middle;
	}*/
}

int QS::partition(int leftIndex, int rightIndex, int pivotIndex){
	cout << "Entering partition" << endl;
	//cout << "pivotIndex = " << pivotIndex << endl;
	cout << getArray() << endl;
	cout << "left: " << leftIndex << " right: " << rightIndex << " pivotIndex: " << pivotIndex << endl;

	/*
	bool done = true;
	for (int i = leftIndex; i < rightIndex; i++){
		if (a[i] > a[i + 1]){
			done = false;
		}
	}*/

	if (indexCounter == 0 || rightIndex < leftIndex || pivotIndex > rightIndex || pivotIndex < leftIndex || leftIndex < 0 || rightIndex >= size || rightIndex - leftIndex == 0){
		//cout << "Exiting partition with error" << endl;
		return -1;
	}

	int pivotVal = a[pivotIndex];
	//cout << "Pivotval = " << pivotVal << endl;
	switchVals(a[leftIndex], a[pivotIndex]);
	cout << getArray() << endl;

	int up = leftIndex + 1;
	int down = rightIndex;
	do {
		//cout << "Running do loop" << endl;
		while ((up != rightIndex) && !(a[leftIndex] < a[up])){
			++up;
		}
		while ((a[down] >= a[leftIndex]) && (down > leftIndex)){
			--down;
		}
		if (up < down){
			//cout << "UP: " << up << " DOWN: " << down << endl;
			switchVals(a[up], a[down]);
			cout << getArray() << endl;
		}
	} while (up < down);
	cout << "Done, up: " << up << " down: " << down << endl;
	
	switchVals(a[leftIndex], a[down]);
	cout << "Exiting partition" << endl;
	cout << getArray() << endl;// << endl;
	//return pivotIndex;
	cout << "PVal: " << pivotVal << " a[right]: " << a[rightIndex] << " a[left]: " << a[leftIndex] << endl;// << endl; 
	if (pivotVal == a[rightIndex]&& a[rightIndex] == a[leftIndex]){
		cout << "returning ri: " << rightIndex << endl << endl;
		return rightIndex;
	}
	else{
		cout << "returning down: " << down << endl << endl;
		return down;
	}
	
}

void QS::bubbleSort(int& first, int& last, int& middle){
	int tmpArray[] = {a[first], a[middle], a[last]};
	while (tmpArray[1] < tmpArray[0] || tmpArray[2] < tmpArray[0] || tmpArray[2] < tmpArray[1]){
		for (int i = 0; i < 2; i++){
			if (tmpArray[i + 1] < tmpArray[i]){
				int tmp = tmpArray[i + 1];
				tmpArray[i + 1] = tmpArray[i];
				tmpArray[i] = tmp;
			}
		}
	}
	
	a[first] = tmpArray[0];
	a[middle] = tmpArray[1];
	a[last] = tmpArray[2];

}

int QS::switchVals(int& a, int& b){
	int tmp = a;
	a = b;
	b = tmp;
}