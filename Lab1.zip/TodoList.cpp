#ifndef TODO_LIST_CPP_
#define TODO_LIST_CPP_
#include <vector>
#include <string>
#include "TodoList.h"

TodoList::TodoList(){
	cout << "In constructor" << endl;
		ifstream inFile;
		inFile.open("TODOList.txt");

		if (inFile.is_open()){
			string line;
			while (getline(inFile, line)){
				tasksList.push_back(line);
			}
		}

		inFile.close();
}

TodoList::~TodoList(){
	cout << "In destructor" << endl;
		ofstream outFile;
		outFile.open("TODOList.txt", ofstream::out | ofstream::trunc);

		if (outFile.is_open()){
			for (int i = 0; i < tasksList.size(); i++){
				outFile << tasksList.at(i) << endl;
			}
			//printTodoList();
		}

		outFile.close();
}

void TodoList::add(string _duedate, string _task){
	cout << "In add" << endl;
	tasksList.push_back(_duedate + " " + _task);
}

int TodoList::remove(string _task){
		cout << "In remove" << endl;
		for (int i = 0; i < tasksList.size(); i++){
			int spaceIndex = tasksList.at(i).find_first_of(' ');
			string taskOnly = tasksList.at(i).substr(spaceIndex + 1);
			if (_task == taskOnly){
				tasksList.erase(tasksList.begin() + i);
			}
		}
	}

void TodoList::printDaysTasks(string _date){
		for (int i = 0; i < tasksList.size(); i++){
			int spaceIndex = tasksList.at(i).find_first_of(' ');
			string taskDate = tasksList.at(i).substr(0,spaceIndex);
			
			if (taskDate == _date){
				cout << tasksList.at(i) << endl;
			}
		}
	}

void TodoList::printTodoList(){
	for (int i = 0; i < tasksList.size(); i++){
		cout << tasksList.at(i) << endl;
	}
}

#endif