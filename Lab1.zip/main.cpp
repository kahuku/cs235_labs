#include <iostream>
#include "TodoList.h"

using namespace std;

int main(int argc, char* argv[]) {
	TodoList list;

	/*for (int i = 0; i < argc; i++){
		cout << "Arg " << i << ": " << argv[i] << endl;
	}*/

	string command = argv[1];
	if (command == "add"){
		string date = argv[2];
		string task = argv[3];
		list.add(date, task);
		cout << "Task added successfully." << endl;
	}
	else if (command == "printlist"){
		list.printTodoList();
	}
	else if (command == "remove"){
		string toRemove = argv[2];
		list.remove(toRemove);
	}
	else if (command == "printDay"){
		string dayToPrint = argv[2];
		list.printDaysTasks(dayToPrint);
	}
  return 0;
}