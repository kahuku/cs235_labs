#ifndef TODO_LIST_H_
#define TODO_LIST_H_

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include "TodoListInterface.h"

using namespace std;

class TodoList : public TodoListInterface {
public:
	TodoList();
  virtual ~TodoList();
  virtual void add(string, string);
  virtual int remove(string);
  virtual void printTodoList();

  virtual void printDaysTasks(string _date);
private:
	vector <string> tasksList;
};

#endif